Upload index.html to a public GitHub repo and enable GitHub Pages under Settings → Pages.
